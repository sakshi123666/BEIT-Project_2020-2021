#Ecommerce Android Mobile Application -    e-commerce Online Shopping Application  

The application has been designed for e-commerce purpose alongside its dashboard [Dashbaord](https://github.com/Akbari300/Ecommerce-Android-Application-Dashboard.git), project had learning purpose and will get ready for business purpose after few improvements. the completely e-commerce funationality listed bellow, the Main purpose was to implement Semantic search and Apriori Algorithm for products suggestions. if you wanna know more in details feel free to reach me out. contact bellow. 



Application has been designed using [fresco](https://github.com/facebook/fresco) library for image loading and caching. All new features like top eCommerce app have been added in this app. This app is best practice for Android Developers.

for any inquery
personal website: https://www.aliakbari.co <br/>
email: akbarialiahmad@gmail.com




<b>Ecommerce Functionalities:</b>

1. Products categories 
2. Semantic Product Search 
3. product recommendation using Apriori Algorithm 
4. product order, account login and registration
5. Loading and caching images with RecyclerView and CardView.
6. Add to Cart and Wishlist, manage cart and wishlist.
7. Category wise items/products loading and caching in list.
8. Detailed item description.
9. All other options available in side Navigation Drawer.
10. Introslider at starting of application.
11. Material design based app.


Note: Please consider the below points

copywrite: code avialable for opensource. feel free to use but consider the copy write standards (fork). 

###Screen shots: 

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/first.png" align="left" height="500" width="260" ></a>

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/second.png" align="left" height="500" width="260" ></a>

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/third.png" align="left" height="500" width="260" ></a>


<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/four.png" align="left" height="500" width="260" ></a>

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/fifth.png" align="left" height="500" width="260"></a>

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/sixth.png" align="left" height="500" width="260" ></a>

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/seventh.png" align="left" height="500" width="260" ></a>

<a href="url"><img src="https://github.com/Akbari300/Complete-Ecommerce-Android-Application-/blob/master/screenshots/eight.png" align="left" height="500" width="260" ></a>


