package com.allandroidprojects.ecomsample.miscellaneous;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.allandroidprojects.ecomsample.R;
import com.allandroidprojects.ecomsample.startup.MainActivity;
import com.allandroidprojects.ecomsample.startup.MyAccount;

public class EmptyActivity extends AppCompatActivity {

    private final String KEY = "edittextValue";
    TextView tv;
    EditText tx;
    SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);
        CardView view = (CardView) findViewById(R.id.btnlogin);
        pref = getApplicationContext().getSharedPreferences(KEY, MODE_PRIVATE);
        tx = (EditText) findViewById(R.id.tvInfo);
        tv = (TextView) findViewById(R.id.textInfo);

        view.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                saveFromEditText(tx.getText().toString());
                tv.setText(getValue());
                tx.setVisibility(View.GONE);
                tv.setVisibility(View.VISIBLE);
                Toast.makeText(getApplicationContext(), "Submitted succesfully", Toast.LENGTH_SHORT).show();
            }

        });
    }

    private String getValue() {
        String savedValue = pref.getString(KEY, ""); //the 2 argument return default value

        return savedValue;
    }

    private void saveFromEditText(String text) {
        Log.d("PMS", "SAVED");
        //SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(KEY, text);
        editor.commit();
    }
}
