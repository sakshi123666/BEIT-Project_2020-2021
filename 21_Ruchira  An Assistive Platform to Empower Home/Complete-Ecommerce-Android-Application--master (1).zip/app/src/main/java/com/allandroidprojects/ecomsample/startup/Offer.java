package com.allandroidprojects.ecomsample.startup;



public class Offer extends SuperClass {


    public Offer()
    {

        super();
        offers.add(new Word("Cakes/केक", "Tasty cakes", "350 Rs"));
        offers.add(new Word("Jewellery Cleaner/ज्वेलरी क्लिनर", "You do not have to spend hours scrubbing your jewellery to remove tarnish", "50 RS"));
        offers.add(new Word("Scarves/स्कार्फ", "Made in variety of different materials such as wool, silk, cotton", "180 Rs"));
        offers.add(new Word("Lipstick/लिपस्टिक", "Homemade lip balm gives a better protection, gloss and softness to the lips as compared to marketed products", "200 Rs"));
        offers.add(new Word("Homemade Soap/साबून/साबण", "This soap is made without Iye using melt and pour method", "75 Rs"));
        offers.add(new Word("Beaded earrings/मणी कानातले", "The pieces are soldered, sawed, carved and shaped without the use of mass produced manufacturing machinery.", "65 Rs"));



    }





}
