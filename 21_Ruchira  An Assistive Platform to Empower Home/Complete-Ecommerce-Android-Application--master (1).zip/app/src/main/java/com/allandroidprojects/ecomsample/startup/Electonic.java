package com.allandroidprojects.ecomsample.startup;

public class Electonic extends SuperClass {

    public Electonic()
    {

        super();
        offers.add(new Word("Scarves/स्कार्फ", "Made in variety of different materials such as wool, silk, cotton", "180 Rs"));

        offers.add(new Word("Sweaters/स्वेटर", "A knitted or crocheted jacket or pullover", "720 Rs"));
        offers.add(new Word("Gloves/हातमोजा", "Get comfortable pair of gloves for winter season", "250 Rs"));
        offers.add(new Word("Materials/पोशाख साहित्य/ पोशाक सामग्री\n \n", "Get materials as you like which later can be stitched", "600 Rs"));
    }
}
