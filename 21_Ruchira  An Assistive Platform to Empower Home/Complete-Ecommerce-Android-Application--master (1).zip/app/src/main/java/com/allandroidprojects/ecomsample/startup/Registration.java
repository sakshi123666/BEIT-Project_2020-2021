package com.allandroidprojects.ecomsample.startup;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.allandroidprojects.ecomsample.startup.MyAccount;

import com.allandroidprojects.ecomsample.R;
import com.allandroidprojects.ecomsample.utility.PrefManager;

import java.util.regex.Pattern;

public class Registration extends AppCompatActivity {

    private PrefManager prefManager;
    private MyAccount mc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        prefManager = new PrefManager(this);
        mc = new MyAccount();

        TextView login = (TextView) findViewById(R.id.txtlogintext);
        final EditText email = (EditText) findViewById(R.id.txtUserName);
        final EditText mother = (EditText) findViewById(R.id.txtMothersname);
        final EditText password = (EditText) findViewById(R.id.txtPassword);
        

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Registration.this, MyAccount.class));
            }
        });


        Button register = (Button) findViewById(R.id.btnRegister);
        register.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view)
            {
                if(isValidEmailId(email.getText().toString().trim())) {
                    Intent i = new Intent();
                    i.putExtra("email", email.getText().toString());
                    i.putExtra("mommy", mother.getText().toString());
                    i.putExtra("pass", password.getText().toString());
                    setResult(Activity.RESULT_OK, i);
//                    mc.addElement(email.getText().toString());
                    Toast.makeText(Registration.this, "Registered Successfully!", Toast.LENGTH_SHORT).show();
//                    startActivity(new Intent(Registration.this, MyAccount.class));
                    finish();
                } else {
                    Toast.makeText(Registration.this, "Please enter a valid email id.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
}
