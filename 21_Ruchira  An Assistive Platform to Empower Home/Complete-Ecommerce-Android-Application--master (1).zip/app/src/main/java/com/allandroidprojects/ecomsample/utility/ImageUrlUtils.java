package com.allandroidprojects.ecomsample.utility;

import java.util.ArrayList;

/**
 * Created by 06peng on 2015/6/24.
 */
public class ImageUrlUtils {
    static ArrayList<String> wishlistImageUri = new ArrayList<>();
    static ArrayList<String> cartListImageUri = new ArrayList<>();

    public static String[] getImageUrls() {
        String[] urls = new String[] {
                "https://static.pexels.com/photos/5854/sea-woman-legs-water-medium.jpg",
                "https://static.pexels.com/photos/6245/kitchen-cooking-interior-decor-medium.jpg"

        };
        return urls;
    }

    public static String[] getOffersUrls() {
        String[] urls = new String[]{
                "https://i.imgur.com/NPKK51t.jpg",
                "https://i.imgur.com/8JyKkeI.jpg",
                "https://i.imgur.com/nY0lNDv.jpg",
                "https://i.imgur.com/Vi48aPR.jpg",
                "https://i.imgur.com/NSKL3lS.jpg",
                "https://i.imgur.com/R5tRxIN.jpg"

        };
        return urls;
    }

    public static String[] getHomeApplianceUrls() {
        String[] urls = new String[]{
                "https://i.imgur.com/NPKK51t.jpg",
                "https://i.imgur.com/rrQKJT7.jpg",
                "https://i.imgur.com/2kpZVSD.jpg",
                "https://i.imgur.com/dE6yFy5.jpg"

        };
        return urls;
    }

    public static String[] getElectronicsUrls() {
        String[] urls = new String[]{
                "https://i.imgur.com/nY0lNDv.jpg",
                "https://i.imgur.com/NKFZWrK.jpg",
                "https://i.imgur.com/dLpueal.jpg",
                "https://i.imgur.com/zfNqWvz.jpg"


        };
        return urls;
    }

    public static String[] getLifeStyleUrls() {
        String[] urls = new String[]{
                "https://i.imgur.com/Vi48aPR.jpg",
                "https://i.imgur.com/NSKL3lS.jpg",
                "https://i.imgur.com/auVWsHN.jpg"
        };
        return urls;
    }

    public static String[] getBooksUrls() {
        String[] urls = new String[]{
                "https://i.imgur.com/8JyKkeI.jpg",
                "https://i.imgur.com/R5tRxIN.jpg",
                "https://i.imgur.com/8UlNN5a.jpg",

        };
        return urls;
    }

    // Methods for Wishlist
    public void addWishlistImageUri(String wishlistImageUri) {
        this.wishlistImageUri.add(0,wishlistImageUri);
    }

    public void removeWishlistImageUri(int position) {
        this.wishlistImageUri.remove(position);
    }

    public ArrayList<String> getWishlistImageUri(){ return this.wishlistImageUri; }

    // Methods for Cart
    public void addCartListImageUri(String wishlistImageUri) {
        this.cartListImageUri.add(0,wishlistImageUri);
    }

    public void removeCartListImageUri(int position) {
        this.cartListImageUri.remove(position);
    }

    public ArrayList<String> getCartListImageUri(){ return this.cartListImageUri; }
}
