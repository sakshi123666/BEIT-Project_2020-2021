package com.allandroidprojects.ecomsample.startup;

public class Book extends SuperClass {

    public Book()
    {

        super();
        offers.add(new Word("Jewellery Cleaner/ज्वेलरी क्लिनर", "You do not have to spend hours scrubbing your jewellery to remove tarnish", "50 Rs"));

        offers.add(new Word("Beaded earrings/ मणी कानातले ", "The pieces are soldered, sawed, carved and shaped without the use of mass produced manufacturing machinery.", "130 Rs"));
        offers.add(new Word("Necklace set/ हार सेट\n", "Obtain jewellery set of different colors", "500Rs"));

    }

}
