package com.allandroidprojects.ecomsample.startup;

public class More extends SuperClass {

    public More()
    {


       super();
        offers.add(new Word("Homemade spices/ घरगुती मसाले", "Try variety of spices which are handmade", "100 Rs"));
        offers.add(new Word("Homemade sweets/ होममेड मिठाई", "Try variety of sweets handmade", "100 Rs"));
    }
}
