package com.allandroidprojects.ecomsample.startup;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Toast;

import com.allandroidprojects.ecomsample.R;
import com.allandroidprojects.ecomsample.utility.PrefManager;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class MyAccount extends AppCompatActivity {

    private PrefManager prefManager;
    public ArrayList<String> all = new ArrayList<>();
    public ArrayList<String> huehue = new ArrayList<>();
    public ArrayList<String> mother = new ArrayList<>();
    public ArrayList<String> pass = new ArrayList<>();
    public ArrayList<String> hihi = new ArrayList<>();
    public ArrayList<String> passy = new ArrayList<>();
    private int myid = 1;
    private int idmy = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        prefManager = new PrefManager(this);
        add();
        for (String member : all){
            Log.i("Member name: ", member);
        }
        for (String member : passy){
            Log.i("Member name: ", member);
        }
        for (String member : hihi){
            Log.i("Member name: ", member);
        }
        for (String member : mother){
            Log.i("Member name: ", member);
        }

        TextView register = (TextView) findViewById(R.id.registerclick);
        TextView forgot = (TextView) findViewById(R.id.forgotPassword);
        final EditText email = (EditText) findViewById(R.id.txtUrname);
        final EditText password = (EditText) findViewById(R.id.txtPassword);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(MyAccount.this, Registration.class), myid);
            }
        });

        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivityForResult(new Intent(MyAccount.this, Forgot.class), idmy);
            }
        });

        CardView view = (CardView) findViewById(R.id.btnlogin);

        view.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                if(isValidEmailId(email.getText().toString().trim())){
                    Log.i("TAG", email.getText().toString());
                    if (all.contains(email.getText().toString()) || huehue.contains(email.getText().toString()) || hihi.contains(email.getText().toString())) {
                        if(pass.contains(password.getText().toString()) || passy.contains(password.getText().toString())) {
                            startActivity(new Intent(MyAccount.this, MainActivity.class));
                        } else {
                            Toast.makeText(getApplicationContext(),"Wrong password", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(),"User not found. Please register.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                }

                for (String member : all){
                    Log.i("Member name: ", member);
                }
            }

        });

    }

    private boolean isValidEmailId(String email) {
        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }

    public void addElement(String anujayedi) {
        huehue.add(anujayedi);
        for (String member : huehue){
            Log.i("Member name: ", member);
        }
    }

    public void add() {
        all.add("anujaapte99@gmail.com");
        all.add("mayuridesh16022000@gmail.com");
        all.add("pratham220399@gmail.com");
        all.add("sakhijain932000@gmail.com");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == myid && resultCode == Activity.RESULT_OK) {
            String email1 = data.getStringExtra("email");
            String mom = data.getStringExtra("mommy");
            String passw = data.getStringExtra("pass");
            huehue.add(email1);
            mother.add(mom);
            pass.add(passw);
        }
        if (requestCode == idmy && resultCode == 2000) {
            String newpass = data.getStringExtra("passwordnew");
            passy.add(newpass);
            String jaja = data.getStringExtra("newemail");
            hihi.add(jaja);
        }
    }
}
