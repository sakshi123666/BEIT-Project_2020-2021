package com.allandroidprojects.ecomsample.startup;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.allandroidprojects.ecomsample.startup.MyAccount;

import com.allandroidprojects.ecomsample.R;
import com.allandroidprojects.ecomsample.utility.PrefManager;

import java.util.regex.Pattern;

public class Forgot extends AppCompatActivity {

    private MyAccount mc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);
        mc = new MyAccount();

        final EditText email = (EditText) findViewById(R.id.txtFname);
        final EditText mom = (EditText) findViewById(R.id.txtLname);
        final EditText newpassword = (EditText) findViewById(R.id.txtPassword);
        final EditText cfpass = (EditText) findViewById(R.id.cfPassword);


        Button register = (Button) findViewById(R.id.btnRegister);
        register.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view)
            {
                if(isValidEmailId(email.getText().toString().trim())) {
                            Intent ji = new Intent();
                            ji.putExtra("passwordnew", newpassword.getText().toString());
                            ji.putExtra("newwmail", email.getText().toString());
                            setResult(2000, ji);
                            Toast.makeText(Forgot.this, "Password was reset!", Toast.LENGTH_SHORT).show();
                            finish();
                } else {
                    Toast.makeText(Forgot.this, "Please enter a valid email id.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private boolean isValidEmailId(String email){

        return Pattern.compile("^(([\\w-]+\\.)+[\\w-]+|([a-zA-Z]{1}|[\\w-]{2,}))@"
                + "((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\."
                + "([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\\.([0-1]?"
                + "[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
                + "([a-zA-Z]+[\\w-]+\\.)+[a-zA-Z]{2,4})$").matcher(email).matches();
    }
}
