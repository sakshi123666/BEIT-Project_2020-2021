package com.allandroidprojects.ecomsample.utility;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Lincoln on 05/05/16.
 */
public class PrefManager {
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;

    // shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences constants
    private static final String PREF_NAME = "MyPreference";
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";
    public List<String> al = new ArrayList<>();


    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return pref.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    public void addElement(String anujayedi) {
        al.add(anujayedi);
        add();
        for (String member : al){
            Log.i("Member name: ", member);
        }
    }

    public void add() {
        al.add("anujaapte99@gmail.com");
        al.add("mayuridesh16022000@gmail.com");
        al.add("pratham220399@gmail.com");
        al.add("sakhijain932000@gmail.com");
    }

    public boolean check(String anuja) {
        if (al.contains(anuja)) {
            return true;
        }
        return false;
    }

}
