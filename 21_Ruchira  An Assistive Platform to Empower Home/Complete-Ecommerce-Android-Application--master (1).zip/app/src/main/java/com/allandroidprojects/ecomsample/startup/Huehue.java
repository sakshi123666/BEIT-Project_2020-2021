package com.allandroidprojects.ecomsample.startup;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.allandroidprojects.ecomsample.R;

public class Huehue extends AppCompatActivity {
    private WebView webView = null;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);
        WebView webView = (WebView) findViewById(R.id.webview);


        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        Webview webViewClient = new Webview(this);
        webView.setWebViewClient(webViewClient);

        webView.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLSeOu2zuWWPk1RJD8DOivl8fXDDThWTVWmTB3w8o62G1Y8vjZA/viewform");
    }
}