package com.allandroidprojects.ecomsample.startup;

import java.util.ArrayList;
import java.util.List;

import com.allandroidprojects.ecomsample.R;

public class SearchProduct {

    public final List<Item> productList;

    public SearchProduct()
    {

        productList = new ArrayList<>();

        //offer products;
        productList.add(new Item("Cakes", "Tasty cakes are much healthier option and can be ordered in any flavour.", "350 Rs",
        R.drawable.offer_quitar, "https://i.imgur.com/NPKK51t.jpg"));

        productList.add(new Item("Jewellery Cleaner", "You do not have to spend hours scrubbing your jewellery to remove tarnish", "50 Rs",
                R.drawable.offer_glasses, "https://i.imgur.com/8JyKkeI.jpg"));

        productList.add(new Item("Scarves","Made in variety of different materials such as wool, silk, cotton", "180 Rs",
                R.drawable.offer_clock, "https://i.imgur.com/nY0lNDv.jpg"));


        productList.add(new Item("Lipstick", "Homemade lip balm gives a better protection, gloss and softness to the lips as compared to marketed products", "200 Rs",
                R.drawable.offer_sewing_machine, "https://i.imgur.com/Vi48aPR.jpg"));

        productList.add(new Item("Homemade Soap","This soap is made without Iye using melt and pour method", "75 Rs",
                R.drawable.offer_lump, "https://i.imgur.com/NSKL3lS.jpg"));

        productList.add(new Item("Beaded earrings", "The pieces are soldered, sawed, carved and shaped without the use of mass produced manufacturing machinery.", "65 Rs",
                R.drawable.offer_camera, "https://i.imgur.com/R5tRxIN.jpg"));


        // Clothing

        productList.add(new Item("Scarves/स्कार्फ", "Made in variety of different materials such as wool, silk, cotton", "180 Rs",
                R.drawable.electronic_desktop_computer, "https://i.imgur.com/nY0lNDv.jpg"));

        productList.add(new Item("Sweaters/स्वेटर", "A knitted or crocheted jacket or pullover", "720 Rs",
                R.drawable.electornic_samsung_phone, "https://i.imgur.com/NKFZWrK.jpg"));


        productList.add(new Item("Gloves/हातमोजा", "Get comfortable pair of gloves for winter season", "250 Rs",
                R.drawable.electronic_screen_player, "https://i.imgur.com/dLpueal.jpg"));



        // Beauty
        productList.add(new Item("Lipstick/ लिपस्टिक", "Homemade lip balm gives a better protection, gloss and softness to the lips as compared to marketed product", "200 Rs",
                R.drawable.lifestyle_red_dress, "https://i.imgur.com/Vi48aPR.jpg"));

        productList.add(new Item("Homemade Soap/ साबून/साबण", "This soap is made without Iye using melt and pour method","75 Rs",
                R.drawable.lifestyle_spring_white_dress, "https://i.imgur.com/NSKL3lS.jpg"));

        productList.add(new Item("Face scrub/ चेहरे के लिए स्क्र/स्क्रब ", "Used to remove debris and dead skin cells.", "250 Rs",
                R.drawable.lifestyle_black_bow_tie, "https://i.imgur.com/auVWsHN.jpg"));


        //Bakery
        productList.add(new Item("Cakes/केक", "Tasty cakes are much healthier option and can be ordered in any flavour", "350 Rs",
                R.drawable.home_double_bed, "https://i.imgur.com/NPKK51t.jpg"));

        productList.add(new Item("Homemade bread/ब्रेड", "Try the best light and airy bread", "100 Rs for a loaf",
                R.drawable.home_drawing_art, "https://i.imgur.com/rrQKJT7.jpg"));

        productList.add(new Item("Muffins/मफिन", "Order the best moist muffins in any flavour", "180 for 6M",
                R.drawable.home_sofa_pillow, "https://i.imgur.com/2kpZVSD.jpg"));





        //Jwellery

        productList.add(new Item("Jewellery Cleaner/ज्वेलरी क्लिनर", "You do not have to spend hours scrubbing your jewellery to remove tarnish",  "50 Rs",
                R.drawable.book_happy, "https://i.imgur.com/8JyKkeI.jpg"));

        productList.add(new Item("Beaded earrings/ मणी कानातले ", "The pieces are soldered, sawed, carved and shaped without the use of mass produced manufacturing machinery.", "130 Rs",
                R.drawable.book_diary_notebook, "https://i.imgur.com/R5tRxIN.jpg"));

        productList.add(new Item("Necklace set/ हार सेट", "Obtain jewellery set of different colors", "500Rs",
                R.drawable.home_holy_books, "https://i.imgur.com/8UlNN5a.jpg"));


    }// end of constructor




    public List<Item> getProductList(){
        return productList;
    }

}
