package com.allandroidprojects.ecomsample.startup;

public class Home extends SuperClass {

    public Home()
    {

        super();
        offers.add(new Word("Cakes/केक", "Tasty cakes are much healthier option and can be ordered in any flavour.", "350 Rs"));

        offers.add(new Word("Homemade bread/ब्रेड ", "Try the best light and airy bread", "100 Rs for a loaf"));
        offers.add(new Word("Muffins/मफिन", "Order the best moist muffins in any flavour", "180 for 6M"));
        offers.add(new Word("Monster cookie bars/कुकी बार\n", "Enjoy the best monster cookies with organic products", "200 for 6MC"));
    }
}
