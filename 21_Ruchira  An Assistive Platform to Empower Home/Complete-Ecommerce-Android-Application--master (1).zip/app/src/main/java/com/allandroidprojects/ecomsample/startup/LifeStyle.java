package com.allandroidprojects.ecomsample.startup;

public class LifeStyle extends SuperClass {

    public LifeStyle()
    {
        super();

        offers.add(new Word("Lipstick/ लिपस्टिक/\n", "Homemade lip balm gives a better protection, gloss and softness to the lips as compared to marketed products", "200 Rs/ "));
        offers.add(new Word("Homemade Soap/ साबून/साबण ", "This soap is made without Iye using melt and pour method", "75 Rs"));
        offers.add(new Word("Face scrub/ चेहरे के लिए स्क्र/स्क्रब ", "Used to remove debris and dead skin cells.", "250 Rs"));
    }
}
